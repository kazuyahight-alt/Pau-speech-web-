const textInput = document.getElementById("textInput");
const charCount = document.getElementById("charCount");
const statusText = document.getElementById("statusText");
const aiVoice = document.getElementById("aiVoice");
const styleSelect = document.getElementById("styleSelect");
const browserVoice = document.getElementById("browserVoice");
const speedRange = document.getElementById("speedRange");
const speedValue = document.getElementById("speedValue");
const aiButton = document.getElementById("aiButton");
const browserButton = document.getElementById("browserButton");
const pauseButton = document.getElementById("pauseButton");
const resumeButton = document.getElementById("resumeButton");
const stopButton = document.getElementById("stopButton");
const clearButton = document.getElementById("clearButton");
const audioPlayer = document.getElementById("audioPlayer");
const downloadLink = document.getElementById("downloadLink");

let browserVoices = [];
let lastAudioUrl = null;

function setStatus(message) {
  statusText.textContent = message;
}

function getText() {
  return textInput.value.trim();
}

function updateCounter() {
  charCount.textContent = `${textInput.value.length} / 4096`;
}

function setLoading(isLoading) {
  aiButton.disabled = isLoading;
  browserButton.disabled = isLoading;
  clearButton.disabled = isLoading;
  aiButton.textContent = isLoading ? "Generating..." : "Generate AI MP3";
}

function revokeLastAudioUrl() {
  if (lastAudioUrl) {
    URL.revokeObjectURL(lastAudioUrl);
    lastAudioUrl = null;
  }
}

function resetDownload() {
  revokeLastAudioUrl();
  audioPlayer.removeAttribute("src");
  audioPlayer.load();
  downloadLink.href = "#";
  downloadLink.classList.add("disabled");
}

function loadBrowserVoices() {
  if (!("speechSynthesis" in window)) {
    browserVoice.innerHTML = '<option value="">Browser tidak support</option>';
    return;
  }

  browserVoices = window.speechSynthesis.getVoices();
  const currentValue = browserVoice.value;

  browserVoice.innerHTML = '<option value="">Default browser</option>';

  browserVoices.forEach((voice, index) => {
    const option = document.createElement("option");
    option.value = String(index);
    option.textContent = `${voice.name} (${voice.lang})`;
    browserVoice.appendChild(option);
  });

  if (currentValue) {
    browserVoice.value = currentValue;
  }
}

async function generateAiSpeech() {
  const text = getText();

  if (!text) {
    setStatus("Teks masih kosong.");
    textInput.focus();
    return;
  }

  resetDownload();
  window.speechSynthesis?.cancel();
  setLoading(true);
  setStatus("Membuat AI MP3...");

  try {
    const response = await fetch("/api/tts", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        text,
        voice: aiVoice.value,
        style: styleSelect.value,
        speed: Number(speedRange.value)
      })
    });

    const contentType = response.headers.get("content-type") || "";

    if (!response.ok) {
      if (contentType.includes("application/json")) {
        const data = await response.json();
        throw new Error(data.error || "Gagal membuat audio.");
      }
      throw new Error("Gagal membuat audio dari server.");
    }

    const blob = await response.blob();

    if (!blob.size) {
      throw new Error("Audio kosong dari server.");
    }

    lastAudioUrl = URL.createObjectURL(blob);
    audioPlayer.src = lastAudioUrl;
    downloadLink.href = lastAudioUrl;
    downloadLink.classList.remove("disabled");
    setStatus("AI MP3 siap diputar.");
    await audioPlayer.play().catch(() => {});
  } catch (error) {
    setStatus(error.message || "Error tidak diketahui.");
  } finally {
    setLoading(false);
  }
}

function speakInBrowser() {
  const text = getText();

  if (!text) {
    setStatus("Teks masih kosong.");
    textInput.focus();
    return;
  }

  if (!("speechSynthesis" in window)) {
    setStatus("Browser ini tidak support SpeechSynthesis.");
    return;
  }

  window.speechSynthesis.cancel();

  const utterance = new SpeechSynthesisUtterance(text);
  const selectedIndex = Number(browserVoice.value);
  const selectedVoice = browserVoices[selectedIndex];

  if (selectedVoice) {
    utterance.voice = selectedVoice;
    utterance.lang = selectedVoice.lang;
  } else {
    utterance.lang = "id-ID";
  }

  utterance.rate = Number(speedRange.value);
  utterance.pitch = 1;
  utterance.volume = 1;

  utterance.onstart = () => setStatus("Browser sedang bicara...");
  utterance.onend = () => setStatus("Selesai.");
  utterance.onerror = () => setStatus("Browser gagal membaca teks.");

  audioPlayer.pause();
  window.speechSynthesis.speak(utterance);
}

function pauseSpeech() {
  if (audioPlayer.src && !audioPlayer.paused) {
    audioPlayer.pause();
    setStatus("Audio MP3 dijeda.");
    return;
  }

  if (window.speechSynthesis?.speaking && !window.speechSynthesis.paused) {
    window.speechSynthesis.pause();
    setStatus("Browser Speech dijeda.");
    return;
  }

  setStatus("Tidak ada audio yang sedang berjalan.");
}

function resumeSpeech() {
  if (audioPlayer.src && audioPlayer.paused && audioPlayer.currentTime > 0) {
    audioPlayer.play().catch(() => setStatus("Audio gagal dilanjutkan."));
    setStatus("Audio MP3 dilanjutkan.");
    return;
  }

  if (window.speechSynthesis?.paused) {
    window.speechSynthesis.resume();
    setStatus("Browser Speech dilanjutkan.");
    return;
  }

  setStatus("Tidak ada audio yang bisa dilanjutkan.");
}

function stopSpeech() {
  if (audioPlayer.src) {
    audioPlayer.pause();
    audioPlayer.currentTime = 0;
  }

  if ("speechSynthesis" in window) {
    window.speechSynthesis.cancel();
  }

  setStatus("Audio dihentikan.");
}

function clearAll() {
  textInput.value = "";
  updateCounter();
  resetDownload();

  if ("speechSynthesis" in window) {
    window.speechSynthesis.cancel();
  }

  setStatus("Dibersihkan.");
  textInput.focus();
}

textInput.addEventListener("input", updateCounter);
speedRange.addEventListener("input", () => {
  speedValue.textContent = `${Number(speedRange.value).toFixed(1)}x`;
});

aiButton.addEventListener("click", generateAiSpeech);
browserButton.addEventListener("click", speakInBrowser);
pauseButton.addEventListener("click", pauseSpeech);
resumeButton.addEventListener("click", resumeSpeech);
stopButton.addEventListener("click", stopSpeech);
clearButton.addEventListener("click", clearAll);

window.addEventListener("beforeunload", () => {
  revokeLastAudioUrl();
  window.speechSynthesis?.cancel();
});

if ("speechSynthesis" in window) {
  loadBrowserVoices();
  window.speechSynthesis.onvoiceschanged = loadBrowserVoices;
}

updateCounter();
