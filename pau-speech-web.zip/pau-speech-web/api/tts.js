import OpenAI from "openai";

const MAX_TEXT_LENGTH = 4096;
const ALLOWED_VOICES = new Set([
  "alloy",
  "ash",
  "ballad",
  "coral",
  "echo",
  "fable",
  "onyx",
  "nova",
  "sage",
  "shimmer",
  "verse",
  "marin",
  "cedar"
]);

const STYLE_INSTRUCTIONS = {
  neutral: "Speak clearly in a natural, neutral tone.",
  calm: "Speak calmly with smooth pacing and gentle intonation.",
  bright: "Speak with a friendly, bright, and confident tone.",
  story: "Read the text like a simple narrator, with natural expression."
};

function sendJson(res, statusCode, data) {
  res.statusCode = statusCode;
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.end(JSON.stringify(data));
}

function parseBody(req) {
  if (!req.body) return {};
  if (typeof req.body === "object") return req.body;

  try {
    return JSON.parse(req.body);
  } catch {
    return {};
  }
}

export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return sendJson(res, 405, { error: "Method not allowed. Use POST." });
  }

  if (!process.env.OPENAI_API_KEY) {
    return sendJson(res, 500, {
      error: "OPENAI_API_KEY belum diatur di environment variable. Browser Speech tetap bisa dipakai."
    });
  }

  const body = parseBody(req);
  const text = String(body.text || "").trim();
  const voice = String(body.voice || "marin").trim();
  const style = String(body.style || "neutral").trim();
  const speedValue = Number(body.speed || 1);

  if (!text) {
    return sendJson(res, 400, { error: "Teks masih kosong." });
  }

  if (text.length > MAX_TEXT_LENGTH) {
    return sendJson(res, 400, {
      error: `Teks terlalu panjang. Maksimal ${MAX_TEXT_LENGTH} karakter.`
    });
  }

  if (!ALLOWED_VOICES.has(voice)) {
    return sendJson(res, 400, { error: "Voice tidak valid." });
  }

  const speed = Number.isFinite(speedValue)
    ? Math.min(2, Math.max(0.5, speedValue))
    : 1;

  const instructions = STYLE_INSTRUCTIONS[style] || STYLE_INSTRUCTIONS.neutral;

  try {
    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

    const audio = await openai.audio.speech.create({
      model: "gpt-4o-mini-tts",
      voice,
      input: text,
      instructions,
      response_format: "mp3",
      speed
    });

    const arrayBuffer = await audio.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    res.statusCode = 200;
    res.setHeader("Content-Type", "audio/mpeg");
    res.setHeader("Content-Disposition", "inline; filename=pauspeech.mp3");
    res.setHeader("Cache-Control", "no-store");
    res.end(buffer);
  } catch (error) {
    const message = error?.message || "Gagal membuat audio.";
    return sendJson(res, 500, { error: message });
  }
}
