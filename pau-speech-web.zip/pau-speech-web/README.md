# Pau Speech Web

Web text-to-speech super simple.

Fitur:

- Generate AI MP3 lewat OpenAI Speech API.
- Browser Speech fallback tanpa API key.
- Pilih AI voice.
- Pilih style suara.
- Atur speed.
- Play audio.
- Pause, resume, stop.
- Download MP3.
- Clear text.
- UI hitam putih sederhana.

## Struktur

```txt
pau-speech-web/
├── api/
│   └── tts.js
├── index.html
├── style.css
├── script.js
├── package.json
├── vercel.json
├── .env.example
├── .gitignore
└── README.md
```

## Cara deploy ke Vercel

1. Upload semua file ini ke repository GitHub bernama `pau-speech-web`.
2. Buka Vercel.
3. Import repository GitHub itu.
4. Masuk ke Project Settings → Environment Variables.
5. Tambahkan variable:

```txt
OPENAI_API_KEY=isi_api_key_kamu
```

6. Redeploy project.
7. Buka web.

## Catatan penting

- Jangan taruh API key di `index.html`, `script.js`, atau file frontend lain.
- API key harus ada di Environment Variables Vercel.
- Kalau API key belum diatur, tombol `Generate AI MP3` akan gagal, tapi tombol `Speak Browser` tetap bisa dipakai.
- GitHub Pages hanya bisa menjalankan bagian frontend/browser speech. AI MP3 butuh backend seperti Vercel.

## Local test

Install dependency:

```bash
npm install
```

Jalankan dengan Vercel CLI:

```bash
npm run dev
```

Buka URL localhost yang muncul di terminal.
